﻿// See https://aka.ms/new-console-template for more information

namespace Assignment_01;

class Program
{
    static void Main(string[] args)
    {
        // Task 1: read the user's name and age, then print them and print if they can vote or not
        Console.WriteLine("Please fill the following information!");
        Console.Write("Name: ");
        string name = Console.ReadLine() ?? string.Empty;
        Console.Write("Age: ");
        string age = Console.ReadLine() ?? string.Empty;
        Console.WriteLine("Hi Mr/Ms " + name + ", Your age is " + age);
        
        // instead of if/else
        // string answer = int.Parse(age) > 18 ? "old enough to vote" : "not old enough to vote";
        string answer;
        if (int.Parse(age) > 18)
            answer = "old enough to vote";
        else answer = "not old enough to vote";
        
        Console.WriteLine(name + ", you are " + answer + '\n');
        
        
        // Task 2: take 3 numbers from the user, then print the smallest and largest numbers
        Console.WriteLine("Please enter 3 numbers!");
        Console.Write("First number: ");
        int first = int.Parse(Console.ReadLine() ?? string.Empty);
        Console.Write("Second number: ");
        int second = int.Parse(Console.ReadLine() ?? string.Empty);
        Console.Write("Third number: ");
        int third = int.Parse(Console.ReadLine() ?? string.Empty);
        
        int largest = first, smallest = first;
        if (smallest > second)
            smallest = second;
        if (smallest > third)
            smallest = third;
        
        if (second > largest)
            largest = second;
        if (third > largest)
            largest = third;
        
        Console.WriteLine("The largest number is: " + largest + ", While the smallest number is: " + smallest);
    }
}